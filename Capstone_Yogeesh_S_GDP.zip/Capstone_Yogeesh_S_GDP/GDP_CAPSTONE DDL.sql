CREATE TABLE STG_FACTS_TABLE (
    [Country_Name] VARCHAR(255),
    [Country_Code] VARCHAR(10),
    [Indicator_Name] VARCHAR(255),
    [Indicator_Code] VARCHAR(50),
    [Year] INT,
    [GDP_VALUE] Decimal(28,12)
);

truncate table STG_FACTS_TABLE
select * from STG_FACTS_TABLE

CREATE TABLE STG_COUNTRY_TABLE(
    [Country_Code] VARCHAR(255),
    [Region] VARCHAR(255),
    [IncomeGroup] VARCHAR(255),
    [SpecialNotes] VARCHAR(255),
    [TableName] VARCHAR(255) 
   
);

ALTER table STG_COUNTRY_TABLE
drop column [SpecialNotes] 

select * from STG_COUNTRY_TABLE
truncate table STG_COUNTRY_TABLE


CREATE TABLE STG_INDICATOR_TABLE (
    [INDICATOR_CODE] VARCHAR(255),
	[INDICATOR_NAME] VARCHAR(255),
	[SOURCE_NOTE] VARCHAR(255),
	[SOURCE_ORGANISATION] VARCHAR(255)
	);

truncate table STG_INDICATOR_TABLE
select * from STG_INDICATOR_TABLE
------------------------------------------------------------------------------------------------------------------------------------------
--DIM TABLES--

CREATE TABLE DIM_TIME (
	Year_ID INT PRIMARY KEY,
    [Year] INT 

);

Truncate table DIM_TIME

CREATE TABLE DIM_COUNTRY(
	[Country_ID] INT PRIMARY KEY,
	[Country_Code] VARCHAR(255),
	[COUNTRY_NAME] VARCHAR(255),
	create_date DATETIME,
    update_time DATETIME
	);

Truncate table DIM_COUNTRY
	

CREATE TABLE DIM_REGION (
	[REGION_ID] INT PRIMARY KEY,
	[REGION] VARCHAR(255)
	);

Truncate table DIM_REGION

CREATE TABLE DIM_INDICATOR (
	[INDICATOR_ID] INT PRIMARY KEY,
	[INDICATOR_CODE] VARCHAR(255),
	[INDICATOR_NAME] VARCHAR(255)
	);

	ALTER TABLE DIM_INDICATOR
ADD create_date DATETIME,
    update_time DATETIME;


Truncate table DIM_INDICATOR

CREATE TABLE DIM_INCOME (
	[INCOMEGROUP_ID] INT PRIMARY KEY,
	[IncomeGroup] VARCHAR(255)
	);

	ALTER TABLE DIM_INCOME
ADD create_date DATETIME,
    update_time DATETIME;

Truncate table DIM_INCOME

-------------------------------------------------------------------------------------------------------
----FACTS TABLE-----------------------------------



CREATE TABLE GDP_FACTS_TABLE (
    GDP_FACT_ID INT PRIMARY KEY,
    Year_ID INT,
    Country_ID INT,
    REGION_ID INT,
    INDICATOR_ID INT,
	INCOMEGROUP_ID INT,
    GDP_VALUE Decimal (28,12),
    create_date DATETIME,
    update_date DATETIME,
    FOREIGN KEY (Year_ID) REFERENCES DIM_TIME(Year_ID),
    FOREIGN KEY (Country_ID) REFERENCES DIM_COUNTRY(Country_ID),
    FOREIGN KEY (REGION_ID) REFERENCES DIM_REGION(REGION_ID),
    FOREIGN KEY (INDICATOR_ID) REFERENCES DIM_INDICATOR(INDICATOR_ID),
	FOREIGN KEY (INCOMEGROUP_ID) REFERENCES DIM_INCOME(INCOMEGROUP_ID)

);

select * from GDP_FACTS_TABLE

drop table GDP_FACTS_TABLE



----------------------------------------------------------------------------------------------------------
-----CHECKING--------------------------
select * from DIM_TIME
select * from DIM_COUNTRY
select * from DIM_REGION
select * from DIM_INDICATOR
select * from DIM_INCOME
select * from GDP_FACTS_TABLE

Truncate table DIM_TIME
Truncate table DIM_COUNTRY
Truncate table DIM_REGION
Truncate table DIM_INDICATOR
Truncate table DIM_INCOME

