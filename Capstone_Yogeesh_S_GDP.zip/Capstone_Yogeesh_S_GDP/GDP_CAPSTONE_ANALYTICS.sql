--TOP 10 countries with its GDP VALUE---------------------------------------------------------
SELECT TOP 10
    country_name,
    YEAR,
    GDP_VALUE
FROM (
    SELECT
        country_name,
        Year,
        GDP_VALUE,
        RANK() OVER (PARTITION BY country_name ORDER BY Year DESC) AS Rank
    FROM STG_FACTS_TABLE
) AS RankedData
WHERE Rank = 1
ORDER BY GDP_VALUE DESC;

----------------------------------------------------------------------------------------------------------------------------------



---Country with Low GDP_VALUE for each YEAR-------------------------------------------
SELECT 
    t.Year, 
    t.Country_Name, 
    t.GDP_VALUE
FROM 
    STG_FACTS_TABLE t
INNER JOIN 
    (
        SELECT 
            Year, 
            MIN(GDP_VALUE) as MinGDP
        FROM 
            STG_FACTS_TABLE
        WHERE 
            Year BETWEEN 1960 AND 2022
        GROUP BY 
            Year
    ) min_t ON t.Year = min_t.Year AND t.GDP_VALUE = min_t.MinGDP
WHERE 
    t.Year BETWEEN 1960 AND 2022;

--Average GDP_VALUE for all countryname	-----------------------------------------------------------------------------------
	SELECT 
    Country_Name, 
    AVG(GDP_VALUE) AS Average_GDP 
FROM 
    STG_FACTS_TABLE 
WHERE 
    Year BETWEEN 1960 AND 2022 
GROUP BY 
    Country_Name 
ORDER BY 
    Average_GDP DESC;


------------------------------------------------------------------------------------------------------------

--Growth Pecentage for each country with each indicator_code--------------------


	SELECT 
    Country_Name, 
    Indicator_Code, 
    Year, 
    GDP_VALUE, 
    LAG(GDP_VALUE) OVER (PARTITION BY Country_Name, Indicator_Code ORDER BY Year) AS Previous_Year_GDP,
    ((GDP_VALUE - LAG(GDP_VALUE) OVER (PARTITION BY Country_Name, Indicator_Code ORDER BY Year)) / NULLIF(LAG(GDP_VALUE) OVER (PARTITION BY Country_Name, Indicator_Code ORDER BY Year), 0)) * 100 AS Growth_Percentage
FROM 
    STG_FACTS_TABLE
WHERE 
    Year BETWEEN 1960 AND 2022;
---------------------------------------------------------------------------------------------------------------
----Identify the country with the fastest-growing GDP from 1960 to 2022------------

WITH Growth AS (
    SELECT 
        Country_Name, 
        GDP_VALUE - LAG(GDP_VALUE) OVER (PARTITION BY Country_Name ORDER BY Year) AS Growth 
    FROM 
        STG_FACTS_TABLE 
    WHERE 
        Year BETWEEN 1960 AND 2022
)
SELECT 
    Country_Name, 
    MAX(Growth) AS Fastest_Growth 
FROM 
    Growth 
GROUP BY 
    Country_Name 
ORDER BY 
    Fastest_Growth DESC;

----------------------------------------------------------------------------------------------------------
---Find the country with the most significant GDP decrease from 1960 to 2022:--------------------------
	WITH Growth AS (
    SELECT 
		
        Country_Name, 
        GDP_VALUE - LAG(GDP_VALUE) OVER (PARTITION BY Country_Name ORDER BY Year) AS Growth 
    FROM 
        STG_FACTS_TABLE 
    WHERE 
        Year BETWEEN 1960 AND 2022
)
SELECT 
	
    Country_Name, 
    MIN(Growth) AS Most_Significant_Decrease 
FROM 
    Growth 
WHERE 
    Growth < 0 
GROUP BY 
    Country_Name 
ORDER BY 
    Most_Significant_Decrease ASC;

-----------------------------------------------------------------------------------------------------------------

---Max-GDP For each year and each indicator_code

SELECT 
    Year, 
    Indicator_Code, 
    MAX(GDP_VALUE) AS Max_GDP
FROM 
    STG_FACTS_TABLE
WHERE 
    Year BETWEEN 1960 AND 2022
GROUP BY 
    Year, Indicator_Code
order BY YEAR;

-------------------------------------------------------------------------------------------------






SELECT 
    Country_Name, 
    Indicator_Code, 
    (
        (SELECT GDP_VALUE FROM STG_FACTS_TABLE WHERE Year = 2022 AND Country_Name = t.Country_Name AND Indicator_Code = t.Indicator_Code) 
        - 
        (SELECT GDP_VALUE FROM STG_FACTS_TABLE WHERE Year = 1960 AND Country_Name = t.Country_Name AND Indicator_Code = t.Indicator_Code)
    ) / 
    (SELECT GDP_VALUE FROM STG_FACTS_TABLE WHERE Year = 1960 AND Country_Name = t.Country_Name AND Indicator_Code = t.Indicator_Code) * 100 AS Total_Growth_Percentage
FROM 
    (SELECT DISTINCT Country_Name, Indicator_Code FROM STG_FACTS_TABLE WHERE Year BETWEEN 1960 AND 2022) t

Order by Country_Name
	